

## About Yasou Project

Creating a personal portfolio based on the Laravel framework. The philosophy behind this project is to control everything with Admin panel

The website uses mainly Laravel 10x including Html and CSS and JavaScript, jQuery for the most frontend functionality and MySQL database

Main area

![](test_images/example_4.png)

About area

![](test_images/example_3.png)

About me

![](test_images/example_2.png)

Portfolio details 

![](test_images/example_1.png)

Admin panel

![](test_images/example_5.png)

More images will be added soon with an explanation, now I'm working on Blog, Categories, Contact me, and Footer.




