-- MySQL dump 10.13  Distrib 8.0.33, for macos13.3 (x86_64)
--
-- Host: localhost    Database: yasou
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `about` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `long_description` text COLLATE utf8mb4_unicode_ci,
  `about_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'Hey I\'m Vag a Junior PHP Developer','Passionate about how tech flows and coding-related subjects','Soon will be updated','Soon will be updated','upload/home_about/1772253240784044.png','2023-07-23 14:59:42','2023-07-23 19:46:38');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_slides`
--

DROP TABLE IF EXISTS `home_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_slides` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_slides`
--

LOCK TABLES `home_slides` WRITE;
/*!40000 ALTER TABLE `home_slides` DISABLE KEYS */;
INSERT INTO `home_slides` VALUES (1,'Hey I\'m Vag a Junior PHP Developer','Passionate about how tech flows and coding-related subjects','upload/home_slide/1772253087590564.png','https://www.youtube.com/watch?v=vlIV2SY7GdI&list=RDvlIV2SY7GdI&start_radio=1','2023-07-23 14:59:42','2023-07-23 19:45:38');
/*!40000 ALTER TABLE `home_slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (18,'2014_10_12_000000_create_users_table',1),(19,'2014_10_12_100000_create_password_reset_tokens_table',1),(20,'2019_08_19_000000_create_failed_jobs_table',1),(21,'2019_12_14_000001_create_personal_access_tokens_table',1),(22,'2023_06_28_133816_add_profile_image_to_users_table',1),(23,'2023_07_08_184433_create_home_slides_table',1),(24,'2023_07_14_181339_create_about_table',1),(25,'2023_07_19_151020_create_multi_images_table',1),(26,'2023_07_23_130640_create_portfolio_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multi_images`
--

DROP TABLE IF EXISTS `multi_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `multi_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multi_images`
--

LOCK TABLES `multi_images` WRITE;
/*!40000 ALTER TABLE `multi_images` DISABLE KEYS */;
INSERT INTO `multi_images` VALUES (1,'upload/multi_images_loc/1772253267647512.png','2023-07-23 19:47:03','2023-07-23 19:47:03'),(2,'upload/multi_images_loc/1772253267664451.png','2023-07-23 19:47:03','2023-07-23 19:47:03'),(3,'upload/multi_images_loc/1772253267678778.png','2023-07-23 19:47:03','2023-07-23 19:47:03'),(4,'upload/multi_images_loc/1772253267694475.png','2023-07-23 19:47:03','2023-07-23 19:47:03'),(5,'upload/multi_images_loc/1772253267714622.png','2023-07-23 19:47:03','2023-07-23 19:47:03'),(6,'upload/multi_images_loc/1772253267729332.png','2023-07-23 19:47:03','2023-07-23 19:47:03'),(7,'upload/multi_images_loc/1772253267744277.png','2023-07-23 19:47:03','2023-07-23 19:47:03');
/*!40000 ALTER TABLE `multi_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portfolio`
--

DROP TABLE IF EXISTS `portfolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portfolio` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `portfolio_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolio`
--

LOCK TABLES `portfolio` WRITE;
/*!40000 ALTER TABLE `portfolio` DISABLE KEYS */;
INSERT INTO `portfolio` VALUES (2,'Laravel','Why Laravel','upload/portfolio/1772235598391195.png','Laravel is a popular and widely-used PHP web application framework, and there are several reasons why it has gained significant popularity among developers:\r\n\r\nElegant Syntax and Structure: Laravel follows an expressive and clean syntax, making it a pleasure to work with. The framework is designed to be simple, easy to read, and developer-friendly.\r\n\r\nMVC Architecture: Laravel follows the Model-View-Controller (MVC) architectural pattern, which promotes the separation of concerns, making code more organized and maintainable.\r\n\r\nBuilt-in Features and Libraries: Laravel comes with a rich set of features out-of-the-box, including an ORM (Object-Relational Mapping) called Eloquent, a powerful routing system, middleware support, database migration tools, authentication, and more. These built-in features help developers build applications more rapidly.\r\n\r\nBlade Templating Engine: Laravel\'s Blade templating engine allows developers to write dynamic and reusable templates with clean syntax, improving the efficiency of frontend development.\r\n\r\nArtisan CLI: Laravel provides the Artisan command-line tool, which offers a wide range of helpful commands to streamline development tasks, such as generating boilerplate code, running migrations, and clearing caches.\r\n\r\nDatabase Migration and Seeders: Laravel\'s migration system allows developers to version control the database schema, making it easy to share and collaborate on database changes. Additionally, Laravel provides seeders to populate the database with test data, facilitating development and testing.\r\n\r\nCommunity and Ecosystem: Laravel has a large and active community of developers. This means there is an abundance of tutorials, packages, and other resources available, making it easier to find solutions to common problems.\r\n\r\nSecurity Features: Laravel takes security seriously and provides features like CSRF (Cross-Site Request Forgery) protection, data validation, and secure authentication methods out-of-the-box.\r\n\r\nIntegration with Third-Party Tools: Laravel integrates well with various third-party tools and services, such as cloud storage systems, email services, caching systems, and more, allowing developers to extend the functionality of their applications easily.\r\n\r\nContinuous Development and Improvements: Laravel\'s development team is committed to continuous improvement and regularly releases updates and new features, ensuring that the framework stays modern and up-to-date with the latest industry trends.\r\n\r\nOverall, Laravel\'s combination of developer-friendly syntax, robust features, and active community support makes it an excellent choice for building web applications of varying complexities. Whether you\'re a beginner or an experienced developer, Laravel can help streamline the development process and deliver high-quality applications.','2023-07-23 15:06:12','2023-07-23 15:06:12'),(3,'PHP','Why PHP','upload/portfolio/1772248004529515.png','PHP (Hypertext Preprocessor) is a server-side scripting language that has been widely used for web development since its inception in the mid-1990s. There are several reasons why PHP continues to be a popular choice for web development:\r\n\r\nEasy to Learn and Use: PHP is known for its simple and straightforward syntax, making it relatively easy for beginners to pick up and start coding. It has a low entry barrier, allowing aspiring developers to quickly get started with web development.\r\n\r\nOpen Source and Free: PHP is an open-source language, which means it is freely available for anyone to use and modify. This accessibility has contributed to its widespread adoption and a large community of developers.\r\n\r\nPlatform Independence: PHP can run on various operating systems (Windows, macOS, Linux, etc.) and is compatible with most web servers (Apache, Nginx, etc.), providing developers with flexibility in their development environments.\r\n\r\nVersatility: PHP is versatile and can be used to build a wide range of web applications, from simple websites to complex web portals and e-commerce platforms.\r\n\r\nVast Community and Resources: PHP has a massive and active community of developers who continuously contribute to its growth and improvement. This has resulted in an extensive library of frameworks, libraries, and resources that developers can leverage to speed up development and solve common challenges.\r\n\r\nBuilt for the Web: PHP was specifically designed for web development, and as such, it comes with built-in functions and features that make handling HTTP requests, form data, and cookies more straightforward.\r\n\r\nIntegration with Databases: PHP has excellent support for working with databases, and it is commonly used with MySQL, one of the most popular database management systems for web applications.\r\n\r\nSpeed and Performance: PHP\'s performance has improved significantly over the years, especially with the introduction of PHP 7 and later versions. When properly optimized, PHP can handle high-traffic websites and web applications efficiently.\r\n\r\nLarge Codebase and Legacy Projects: Many existing websites and applications were built using PHP, creating a substantial amount of legacy code. PHP\'s continued popularity ensures that these projects can be maintained and enhanced effectively.\r\n\r\nContinuous Development and Updates: The PHP language is continually evolving, with regular updates and new features being introduced. This keeps PHP up-to-date with modern web development practices and security standards.','2023-07-23 15:08:37','2023-07-23 18:23:24'),(4,'JS','Why Js','upload/portfolio/1772248291698607.png','JavaScript (JS) is a crucial programming language for web development, and it has become an integral part of building interactive and dynamic websites. There are several reasons why JavaScript is so widely used and considered essential:\r\n\r\nClient-Side Interactivity: JavaScript is primarily a client-side scripting language, which means it runs directly in the user\'s web browser. This enables developers to create interactive and responsive user interfaces, providing a better user experience.\r\n\r\nWide Adoption and Support: JavaScript is supported by all modern web browsers, making it a universal language for web development. It has a vast and active community of developers, which results in extensive documentation, libraries, and frameworks.\r\n\r\nLightweight and Fast: JavaScript is a lightweight language, and the code executes directly in the browser without requiring additional server requests. This can lead to faster page loading times and improved performance.\r\n\r\nAsynchronous Programming: JavaScript supports asynchronous programming through mechanisms like callbacks, Promises, and async/await. This enables handling time-consuming tasks, such as making API calls or loading external resources, without blocking the user interface.\r\n\r\nModern Frameworks and Libraries: JavaScript has an abundance of modern frameworks and libraries that simplify web development. Some popular examples include React, Angular, and Vue.js, which offer powerful tools for building complex applications.\r\n\r\nJSON Format: JavaScript Object Notation (JSON) is a widely used data interchange format. JavaScript can easily parse and generate JSON, making it convenient for exchanging data between the client and the server.\r\n\r\nServer-Side Development: With the introduction of Node.js, JavaScript can now be used for server-side development as well. This allows developers to build full-stack applications using a single language, enhancing code reusability and reducing the learning curve for developers familiar with front-end JavaScript.\r\n\r\nWeb APIs: JavaScript provides access to various Web APIs, such as the DOM API, Geolocation API, Canvas API, and more, allowing developers to interact with different aspects of a user\'s browser and device.\r\n\r\nCommunity-Driven Innovation: The JavaScript community is continually evolving, leading to frequent updates and improvements in the language and related tools. This ensures that JavaScript stays up-to-date with the latest web development trends.\r\n\r\nSupport for Web Standards: JavaScript adheres to web standards set by organizations like the World Wide Web Consortium (W3C). This ensures cross-browser compatibility and a consistent experience for users across different devices and platforms.','2023-07-23 18:27:58','2023-07-23 18:27:58'),(5,'HTML and CSS','Why both are robust','upload/portfolio/1772248360883144.png','HTML (Hypertext Markup Language) and CSS (Cascading Style Sheets) are essential technologies used in web development. They serve distinct purposes but are closely intertwined and complement each other in creating web pages. Here\'s why HTML and CSS are crucial for web development:\r\n\r\nStructure with HTML: HTML is the backbone of web pages. It provides the structural elements necessary to define the content and layout of a web page. HTML uses tags to designate headings, paragraphs, lists, images, links, forms, and more. It creates the logical structure of the content, making it accessible to browsers and other web technologies.\r\n\r\nPresentation with CSS: While HTML defines the structure of a web page, CSS handles its presentation and appearance. CSS allows developers to apply styles, colors, fonts, and layouts to HTML elements, giving the page a visually appealing and consistent look. CSS separates the design from the content, making it easier to maintain and update the website\'s appearance.\r\n\r\nSeparation of Concerns: HTML and CSS follow the principle of separation of concerns, which means that the structure, presentation, and behavior of a web page are handled independently. This modularity makes it easier to manage and update different aspects of the website without affecting others.\r\n\r\nCross-Browser Compatibility: HTML and CSS are supported by all modern web browsers, ensuring that web pages display consistently across different devices and platforms.\r\n\r\nAccessibility: By using HTML\'s semantic elements appropriately and implementing proper structuring, web developers can enhance the accessibility of their websites. This allows users with disabilities or using assistive technologies to navigate and understand the content more effectively.\r\n\r\nResponsive Design: With CSS, developers can create responsive web designs that adapt to various screen sizes and devices. This is crucial in today\'s mobile-centric world, where users access websites from a wide range of devices with different screen dimensions.\r\n\r\nFast Loading Times: HTML and CSS contribute to faster loading times for web pages because they are lightweight and don\'t require extensive processing. Properly optimized HTML and CSS can improve website performance and user experience.\r\n\r\nEase of Learning and Adoption: HTML and CSS have relatively simple syntax and are easy to learn, making them accessible to beginners in web development. The low learning curve allows aspiring developers to quickly start building basic web pages.\r\n\r\nCommunity and Resources: HTML and CSS have been around for a long time, leading to a vast and active community of developers. This means there is a wealth of tutorials, documentation, and online resources available for developers to learn and improve their skills.\r\n\r\nStability and Longevity: HTML and CSS are foundational technologies for the web and have stood the test of time. While web technologies evolve rapidly, the core concepts of HTML and CSS remain relevant and essential for building websites.','2023-07-23 18:29:04','2023-07-23 18:29:04');
/*!40000 ALTER TABLE `portfolio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Evangelos Ilias','Natalisuportman',NULL,'evangelos.ilias87@gmail.com','2023-07-23 15:01:03','$2y$10$CM5jac.Ysn1MARL/2hw2DOFDQJj2QuqNjRrHGBPn7MODfZW62Gxce',NULL,'2023-07-23 15:00:40','2023-07-23 15:01:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-24  1:49:32
