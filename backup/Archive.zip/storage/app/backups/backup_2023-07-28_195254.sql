-- MySQL dump 10.13  Distrib 8.0.33, for macos13.3 (x86_64)
--
-- Host: localhost    Database: yasou
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `about` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `long_description` text COLLATE utf8mb4_unicode_ci,
  `about_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_resume` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'Thanks for visiting my personal portfolio','Please check my CV below','Please check my road map below','Soon will be updated','upload/home_about/1772597135198602.png','resume/1690480371_Evangelos Ilias PHP CV.pdf','2023-07-26 17:24:00','2023-07-27 14:52:51');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (1,'Laravel','2023-07-27 14:48:31','2023-07-27 14:48:31'),(2,'Html','2023-07-27 14:48:39','2023-07-27 14:48:39'),(3,'PHP','2023-07-27 14:48:45','2023-07-27 14:48:45');
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_category_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,'1','Why laravel','upload/blog/1772596952476057.jpeg','laravel','<p>Laravel is a popular and widely used PHP web framework known for its elegant syntax, developer-friendly features, and robust ecosystem. There are several reasons why developers choose Laravel for their web development projects:</p>\r\n<ol>\r\n<li>\r\n<p><strong>Elegant Syntax</strong>: Laravel follows a clean and expressive syntax that makes code easy to read and write. It utilizes modern PHP features and supports the latest PHP versions.</p>\r\n</li>\r\n<li>\r\n<p><strong>Modularity and Extensibility</strong>: Laravel\'s modular design allows developers to use and integrate third-party libraries or create their own modules easily. This helps in keeping the codebase organized and maintainable.</p>\r\n</li>\r\n<li>\r\n<p><strong>Eloquent ORM</strong>: Laravel\'s ORM (Object-Relational Mapping) called Eloquent provides a simple and expressive way to interact with the database. It allows developers to work with database records as objects, making database operations more intuitive and efficient.</p>\r\n</li>\r\n<li>\r\n<p><strong>Database Migrations and Seeding</strong>: Laravel provides built-in support for database migrations and seeding, allowing developers to version-control database schemas and populate the database with test data easily.</p>\r\n</li>\r\n<li>\r\n<p><strong>Routing and Middleware</strong>: Laravel offers a powerful routing system that allows developers to define clean and easy-to-understand URLs for their application. Middleware provides a way to filter HTTP requests entering the application, enabling tasks like authentication, logging, etc.</p>\r\n</li>\r\n<li>\r\n<p><strong>Blade Templating Engine</strong>: Laravel\'s Blade templating engine provides a simple yet powerful way to structure views. It includes features like template inheritance, control structures, and more, making it easy to build dynamic and reusable templates.</p>\r\n</li>\r\n<li>\r\n<p><strong>Authentication and Authorization</strong>: Laravel comes with built-in authentication and authorization features, including pre-built controllers and middleware for user registration, login, and access control.</p>\r\n</li>\r\n<li>\r\n<p><strong>Artisan CLI</strong>: Laravel\'s command-line tool, Artisan, provides various commands to automate repetitive tasks, such as creating models, migrations, controllers, and more. This boosts developer productivity significantly.</p>\r\n</li>\r\n<li>\r\n<p><strong>Testing Support</strong>: Laravel provides robust support for unit testing, making it easier for developers to write and execute tests for their applications, ensuring the stability and reliability of the codebase.</p>\r\n</li>\r\n<li>\r\n<p><strong>Active Community</strong>: Laravel has a large and active community of developers, which means there is extensive documentation, tutorials, packages, and community support available.</p>\r\n</li>\r\n<li>\r\n<p><strong>Security</strong>: Laravel takes security seriously and includes built-in protection against common security vulnerabilities. Additionally, the community frequently updates the framework to address emerging security concerns.</p>\r\n</li>\r\n<li>\r\n<p><strong>Rapid Application Development (RAD)</strong>: With the features mentioned above, Laravel enables developers to build applications quickly, reducing development time and costs.</p>\r\n</li>\r\n</ol>\r\n<p>Overall, Laravel has gained popularity due to its elegant syntax, extensive feature set, and focus on developer productivity, making it a preferred choice for web developers when building modern PHP applications.</p>','2023-07-27 14:49:37','2023-07-27 14:49:46'),(2,'3','Why PHP','upload/blog/1772597007413803.png','php','<p>PHP (Hypertext Preprocessor) is a server-side scripting language that has been widely used for web development since its inception in 1994. There are several reasons why PHP has remained popular and continues to be a preferred choice for many web developers:</p>\r\n<ol>\r\n<li>\r\n<p><strong>Ease of Learning and Use</strong>: PHP is relatively easy to learn, especially for developers who have prior experience with programming languages like C or Perl. Its syntax is simple and straightforward, making it accessible to beginners.</p>\r\n</li>\r\n<li>\r\n<p><strong>Open Source and Free</strong>: PHP is open-source, meaning it is freely available for anyone to use and modify. This has contributed to its widespread adoption and a large community of developers contributing to its growth.</p>\r\n</li>\r\n<li>\r\n<p><strong>Platform Independence</strong>: PHP can run on various operating systems (Windows, Linux, macOS, etc.) and supports multiple web servers. This platform independence makes it highly versatile and adaptable.</p>\r\n</li>\r\n<li>\r\n<p><strong>Extensive Documentation and Community Support</strong>: PHP has a vast community of developers who actively contribute to its documentation, support forums, and open-source libraries. This extensive support ecosystem helps developers find solutions to common problems and share knowledge.</p>\r\n</li>\r\n<li>\r\n<p><strong>Large Ecosystem of Libraries and Frameworks</strong>: PHP has an extensive collection of libraries and frameworks that make it easier for developers to build web applications rapidly. Laravel (as mentioned earlier), Symfony, CodeIgniter, and Zend Framework are some popular PHP frameworks.</p>\r\n</li>\r\n<li>\r\n<p><strong>Wide Hosting Support</strong>: PHP is supported by a vast majority of web hosting providers, making it easy to find hosting solutions for PHP-based websites and applications.</p>\r\n</li>\r\n<li>\r\n<p><strong>Flexibility and Scalability</strong>: PHP is a versatile language that allows developers to build various types of applications, from small websites to large-scale enterprise solutions. It can be used for both frontend and backend development.</p>\r\n</li>\r\n<li>\r\n<p><strong>Integration with Databases</strong>: PHP has strong integration capabilities with different databases, including MySQL, PostgreSQL, SQLite, and more. This allows developers to build dynamic and data-driven web applications.</p>\r\n</li>\r\n<li>\r\n<p><strong>Rapid Development</strong>: With its lightweight and flexible nature, PHP enables rapid development, making it an excellent choice for projects with tight deadlines.</p>\r\n</li>\r\n<li>\r\n<p><strong>Continuous Improvement</strong>: Over the years, PHP has undergone significant improvements, resulting in better performance, security, and modern language features. The PHP development community continually works to enhance the language.</p>\r\n</li>\r\n</ol>\r\n<p>While PHP has faced some criticisms over the years, especially related to certain historical design choices, it continues to evolve and remains a popular choice for web development due to its user-friendly nature, extensive support, and ability to power a wide range of websites and applications.</p>','2023-07-27 14:50:39','2023-07-27 14:50:39');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contact_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (9,'test','test@gmail.com','test','test','Hi there,\r\n\r\nI hope this message finds you well. I came across your website and was impressed with the range of services you offer. I am interested in learning more about your services and how they can benefit my business.\r\n\r\nCould you please provide me with more information about your pricing, packages, and any ongoing promotions or discounts? Additionally, I\'d like to know more about your team and their expertise.\r\n\r\nLooking forward to hearing from you soon.','2023-07-28 14:18:33','2023-07-28 14:18:33'),(10,'test1','test1@gmail.com','test','test','I am writing to explore the possibility of forming a partnership between our organizations. We have been following your work closely and believe that our collaboration could lead to mutually beneficial opportunities.\r\n\r\nOur company specializes in [describe your company\'s expertise], and we see great potential in joining forces with your team to create innovative solutions for our shared audience.\r\n\r\nI would love to schedule a meeting or call to discuss the details further and explore how our strengths can complement each other. Please let me know your availability, and I\'ll be happy to arrange a convenient time for us to connect.\r\n\r\nLooking forward to the possibility of working together.','2023-07-28 14:19:03','2023-07-28 14:19:03');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footers`
--

DROP TABLE IF EXISTS `footers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `footers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `footer_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_short_description` text COLLATE utf8mb4_unicode_ci,
  `footer_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_copyright` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footers`
--

LOCK TABLES `footers` WRITE;
/*!40000 ALTER TABLE `footers` DISABLE KEYS */;
INSERT INTO `footers` VALUES (1,'+44 7928624707','Soon will be updated','10 Paisley St, Leeds','evangelos.ilias87@gmail.com','https://www.linkedin.com/in/evangelos-ilias-a24979110/','Copyright @ 2023 All right Reserved','2023-07-28 07:54:29','2023-07-28 09:07:40');
/*!40000 ALTER TABLE `footers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_slides`
--

DROP TABLE IF EXISTS `home_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_slides` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_slides`
--

LOCK TABLES `home_slides` WRITE;
/*!40000 ALTER TABLE `home_slides` DISABLE KEYS */;
INSERT INTO `home_slides` VALUES (1,'Hey im Evangelos a Junior PHP Developer','Passionate with coding and PHP','upload/home_slide/1772597053806356.png',NULL,'2023-07-26 17:24:00','2023-07-27 14:51:23');
/*!40000 ALTER TABLE `home_slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_06_28_133816_add_profile_image_to_users_table',1),(6,'2023_07_08_184433_create_home_slides_table',1),(7,'2023_07_14_181339_create_about_table',1),(8,'2023_07_19_151020_create_multi_images_table',1),(9,'2023_07_23_130640_create_portfolio_table',1),(10,'2023_07_24_094037_add_about_resume_to_about_table',1),(11,'2023_07_24_121101_create_blog_categories_table',1),(12,'2023_07_25_133757_create_blogs_table',1),(14,'2023_07_28_095940_create_footers_table',2),(15,'2023_07_28_123817_create_contacts_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multi_images`
--

DROP TABLE IF EXISTS `multi_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `multi_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multi_images`
--

LOCK TABLES `multi_images` WRITE;
/*!40000 ALTER TABLE `multi_images` DISABLE KEYS */;
INSERT INTO `multi_images` VALUES (1,'upload/multi_images_loc/1772598573053828.png','2023-07-27 15:15:32','2023-07-27 15:15:32'),(2,'upload/multi_images_loc/1772598573071961.png','2023-07-27 15:15:32','2023-07-27 15:15:32'),(3,'upload/multi_images_loc/1772598573085010.png','2023-07-27 15:15:32','2023-07-27 15:15:32'),(4,'upload/multi_images_loc/1772598573101505.png','2023-07-27 15:15:32','2023-07-27 15:15:32'),(5,'upload/multi_images_loc/1772598573120537.png','2023-07-27 15:15:32','2023-07-27 15:15:32'),(6,'upload/multi_images_loc/1772598573133502.jpeg','2023-07-27 15:15:32','2023-07-27 15:15:32'),(7,'upload/multi_images_loc/1772598745792547.png','2023-07-27 15:18:17','2023-07-27 15:18:17');
/*!40000 ALTER TABLE `multi_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portfolio`
--

DROP TABLE IF EXISTS `portfolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portfolio` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `portfolio_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolio`
--

LOCK TABLES `portfolio` WRITE;
/*!40000 ALTER TABLE `portfolio` DISABLE KEYS */;
INSERT INTO `portfolio` VALUES (1,'GisHolics','This is the GISholics website','upload/portfolio/1772597207514210.png','Soon will be updated','2023-07-27 14:53:50','2023-07-27 14:53:50');
/*!40000 ALTER TABLE `portfolio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (19,'Evangelos Ilias','Natalisuportman',NULL,'evangelos.ilias87@gmail.com','2023-07-27 14:47:48','$2y$10$9tB4Y0mOhtsNusHnsJaqUO.eVamwiN8g06exTUH/OsdiV8fPS/K5O','u79OURKQJNJA0BPWURj66mF3UB1OxfQpCgV0aAXMhuYUUlEgL39u6kFjWsLC','2023-07-27 14:47:23','2023-07-27 14:47:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-28 22:52:54
