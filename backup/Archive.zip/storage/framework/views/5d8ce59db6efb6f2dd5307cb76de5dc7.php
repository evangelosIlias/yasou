<?php $__env->startSection('admin'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<div class="page-content">
    <div class="container-fluid">
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
            
                        <h4 class="card-title">Home Footer Page </h4><br><br>
            
                        <form method="post" action="<?php echo e(route('update.footer')); ?>">
                            <?php echo csrf_field(); ?>

                        <input type="hidden" name='id' value="<?php echo e($homeFooter->id); ?>">

                        
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Footer Number</label>
                            <div class="col-sm-10">
                                <input name="footer_number" class="form-control" type="text" value="<?php echo e($homeFooter->footer_number); ?>"  id="example-text-input">
                            </div>
                        </div>
                        <!-- end row -->

                        
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Footer Address</label>
                            <div class="col-sm-10">
                                <input name="footer_address" class="form-control" type="text" value="<?php echo e($homeFooter->footer_address); ?>"  id="example-text-input">
                            </div>
                        </div>

                        
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Footer Email</label>
                            <div class="col-sm-10">
                                <input name="footer_email" class="form-control" type="text" value="<?php echo e($homeFooter->footer_email); ?>"  id="example-text-input">
                            </div>
                        </div>

                        
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Footer Linkedin</label>
                            <div class="col-sm-10">
                                <input name="footer_linkedin" class="form-control" type="text" value="<?php echo e($homeFooter->footer_linkedin); ?>"  id="example-text-input">
                            </div>
                        </div>

                        
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Footer Copyright</label>
                            <div class="col-sm-10">
                                <input name="footer_copyright" class="form-control" type="text" value="<?php echo e($homeFooter->footer_copyright); ?>"  id="example-text-input">
                            </div>
                        </div>

                        
                        
                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Footer Short Description</label>
                            <div class="col-sm-10">
                                <textarea name="footer_short_description" class="form-control" rows="7"><?php echo e($homeFooter->footer_short_description); ?></textarea>
                            </div>
                        </div>
                        <!-- end row -->
            
                        <input type="submit" class="btn btn-info waves-effect waves-light" value="Update Footer">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- End Section -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/natalisuportman/yasou/resources/views/admin/home_footer/footer.blade.php ENDPATH**/ ?>