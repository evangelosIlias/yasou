<?php $__env->startSection('admin'); ?>


<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Contact Message</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Contact Message</h4>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Contact name</th>
                                <th>Contact Email</th>
                                <th>Contact Subject</th>
                                <th>Contact Number</th>
                                <th>Contact Message</th>
                                <th>Contact Day</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php ($i = 1); ?>
                                <?php $__currentLoopData = $contactMessage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($item->contact_name); ?></td>
                                <td><?php echo e($item->contact_email); ?></td>
                                <td><?php echo e($item->contact_subject); ?></td>
                                <td><?php echo e($item->contact_number); ?></td>
                                <td>
                                    <!-- The button to trigger the pop-up -->
                                    <button type="button" class="btn btn-warning" id="showMessageButton">
                                        <?php echo e($item->contact_message); ?>

                                    </button>

                                <td><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></td>
                                <td>
                                    <a href="<?php echo e(route('delete.contact.message', $item->id)); ?>" class="btn btn-danger sm" title="Delete Data" id='delete'><i class="fas fa-trash"></i></a>    
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div> 
            <!-- end col -->
        </div> 
        <!-- end row -->
    </div>
    <!-- container-fluid -->
</div>
<!-- End Page-content -->

<!-- End Section-->
<?php $__env->stopSection(); ?>


 


<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/natalisuportman/yasou/resources/views/admin/contact/contact_meesage.blade.php ENDPATH**/ ?>