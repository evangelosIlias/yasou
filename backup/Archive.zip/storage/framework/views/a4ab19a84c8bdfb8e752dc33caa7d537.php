<section class="partner">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <ul class="partner__logo__wrap">
                    
                </ul>
            </div>
            <div class="col-lg-6">
                <div class="partner__content">
                    <div class="section__title">
                        <span class="sub-title">05 - technologies</span>
                        <h2 class="title">technologies</h2>
                    </div>
                    <p>I'm a bit of a digital product junky. Over the years, I've used hundreds of web and mobile apps in different industries and verticals. Eventually, I decided that it would be a fun challenge to try designing and building my own.</p>
                    <a href="contact.html" class="btn">Check here</a>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /Users/natalisuportman/yasou/resources/views/frontend/home_all/home_tech.blade.php ENDPATH**/ ?>